<?php
//implementation of delete function 
//is missing due to time reasons