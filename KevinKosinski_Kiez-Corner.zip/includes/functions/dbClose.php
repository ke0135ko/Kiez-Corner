<?php

$server = "localhost";
$user = "student";
$pw = "pwa"; 
$db="kiez corner";

//connect to the DB
$conn = @mysqli_connect($server,$user,$pw,$db);

