<footer>
    <span>Alle Rechte vorbehalten.</span>
</footer>